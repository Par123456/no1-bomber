# no1 bomber
**یک اسمس بمبر رایگان برای ایرانیان**

این اسمس بمبر با 170 وب سرویس اسمس یکی از با کیفیت ترین و سریع ترین اسمس بمبر های موجود در گیتهاب است💊
## قابلیت ها ♦

-  💣 امکان استفاده از پراکسی
-  💊 امکان استفاده از threads 
-  🍇دیزاین زیبا 
-  🔪 سریع و پر سرعت 

## 📃 پیش نیاز ها
- [Python3.11](https://www.python.org/downloads/)
- requests
- PyStyle
## نصب و راه اندازی

پروژه را کلون کنید 🔗

```bash
  git clone https://github.com/Par123456/no1-bomber
```

به فولدر پروژه بروید 📂

```bash
  cd no1-bomber
```

پکیج ها را نصب کنید 🔻

```bash
  pip install -r requirements.txt
```

لذت ببرید 💖

```bash
  python main.py
```


 [به کمک نیاز دارید؟ 🤔](https://t.me/no1_mvp)
 
## استفاده از پروکسی: 
در صورتی که تمایل به استفاده از پروکسی دارید میتونید پروکسی های http تهیه کنید و یه فایل به اسم proxies.txt توی فولدر اصلی بسازید
سورس کد به صورت خودکار ازش استفاده میکنه

## 👨‍🏭 Authors

- [@Parsa no1](https://t.me/no1_mvp)
- [@Par123456](https://github.com/Par123456/no1-bomber)


## 🔗 Telegram
[![Channel Telegram](https://t.me/no1xkurd)](https://t.me/no1_mvp)